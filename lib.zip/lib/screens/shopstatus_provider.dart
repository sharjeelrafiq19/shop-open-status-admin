import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:super_store/api/apis.dart';

class ShopStatusProvider extends ChangeNotifier {
   SharedPreferences? _prefs;
   bool _isShopOpen = false;
   APIs apIs = APIs();

  bool get isShopOpen => _isShopOpen;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _isShopOpen = _prefs!.getBool('isShopOpen') ?? false;
    notifyListeners();
  }

  void updateShopStatus(bool status) {
    _isShopOpen = status;
    _prefs!.setBool('isShopOpen', status);
    apIs.setShopStatus(_isShopOpen);
    notifyListeners();
  }
}
