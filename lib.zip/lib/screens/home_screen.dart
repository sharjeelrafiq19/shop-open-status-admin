import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:super_store/screens/shopstatus_provider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';


class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ShopStatusProvider? shopStatusProvider;

  @override
  void initState() {
    super.initState();
    shopStatusProvider = Provider.of<ShopStatusProvider>(context, listen: false);
    shopStatusProvider!.init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
              appBar: AppBar(
                elevation: 0,
                backgroundColor: const Color(0xff2c462b),
                title: const Text("Makki Karyana Store"),
                centerTitle: true,
              ),
      body: Consumer<ShopStatusProvider>(
        builder: (context, shopStatusProvider, _) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: ShopStatusButton(
                  isShopOpen: shopStatusProvider.isShopOpen,
                  onPressed: _updateButton,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _updateButton() {
    bool isShopOpen = !shopStatusProvider!.isShopOpen;
    shopStatusProvider!.updateShopStatus(isShopOpen);
  }
}

class ShopStatusButton extends StatelessWidget {
  final bool isShopOpen;
  final VoidCallback onPressed;

  const ShopStatusButton({
    required this.isShopOpen,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onPressed,
      color: isShopOpen ? Colors.green : Colors.red,
      minWidth: 150,
      height: 150,
      shape: const CircleBorder(),
      child: Text(
        isShopOpen ? 'Open' : 'Closed',
        style: const TextStyle(fontSize: 30, color: Colors.white),
      ),
    );
  }
}
